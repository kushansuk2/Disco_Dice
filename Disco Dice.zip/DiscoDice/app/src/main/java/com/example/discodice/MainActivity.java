package com.example.discodice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    void Roll(){
        Random random = new Random();
        int dice = random.nextInt(6);
        ImageView ivDice = findViewById(R.id.ivDice1);
        int changeImage = 0;
        switch (dice){
            case 0: changeImage = R.drawable.dice_1;
            break;
            case 1: changeImage = R.drawable.dice_2;
            break;
            case 2: changeImage = R.drawable.dice_3;
            break;
            case 3: changeImage = R.drawable.dice_4;
            break;
            case 4: changeImage = R.drawable.dice_5;
            break;
            case 5: changeImage = R.drawable.dice_6;
            break;
        }
        Toast.makeText(this, (dice+1) + " rolled!", Toast.LENGTH_SHORT).show();
        ivDice.setImageResource(changeImage);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnRoll = findViewById(R.id.btRoll);
        btnRoll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Roll();
            }
        });
    }
}